@extends('layouts.app')

@section('title', $viewData["title"])

@section('subtitle', $viewData["subtitle"])

@section('content')

@if(session('deleted'))
<div class="alert alert-danger">
    <p>{{ session('deleted') }}</p>
</div>
@endif

<div class="row">

    @foreach ($viewData["userStores"] as $userStore)

    <div class="col-md-4 col-lg-3 mb-2">

        <div class="card">

            <img src="https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png?20200919003010">

            <div class="card-body text-center">

                <p class="@if($loop->index < 2) {{ 'fw-bold' }} @endif">{{$userStore["id"]}}</p>
                <a href="{{ route('users.show', ['id'=> $userStore['id']]) }}" class="btn bg-primary text-white">{{ $userStore["email"] }}</a>

            </div>

        </div>

    </div>

    @endforeach

</div>

@endsection