@extends('layouts.app')

@section('content')

<div class="card mb-3">

    <div class="row g-0">

        <div class="col-md-4">

            <img src="https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png?20200919003010">

        </div>

        <div class="col-md-8">

            <div class="card-body">

                <h5 class="card-title">

                    {{ $viewData["userStore"]["id"] }}

                </h5>

                <p class="card-text">{{ $viewData["userStore"]["email"] }}</p>
                <form action="{{ route('users.delete', ['id'=> $viewData['userStore']['id']]) }}" method="post">
                    @csrf
                    <button class="btn bg-primary text-white">Delete</button>
                </form>

            </div>

        </div>

    </div>

</div>

@endsection