@extends('layouts.app')

@section('title', 'Home Page - Online Store')

@section('content')

@if(session('success'))
    <div class="alert alert-success">
        <p>{{ session('success') }}</p>
    </div>
@endif

<form action="{{ route('users.save') }}" method="POST">
    @csrf
    <div class="form-group row">
        <label for="inputid" class="col-sm-2 col-form-label">ID</label>
        <div class="col-sm-10">
            <input name="id" type="int" class="form-control" id="inputid" placeholder="Introduzca un ID">
        </div>
    </div>

    <div class="form-group row">
        <label for="inputemail" class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-10">
            <input name="email" type="text" class="form-control" id="inputemail" placeholder="sunombre@example.com">
        </div>
    </div>

    <div class="form-group row">
        <label for="inputpassword" class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-10">
            <input name="password" type="password" class="form-control" id="inputpassword" placeholder="contraseña">
        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Register</button>
        </div>
    </div>
</form>

@endsection