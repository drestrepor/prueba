<?php $__env->startSection('title', 'Home Page - Online Store'); ?>

<?php $__env->startSection('content'); ?>

<form action="/guardar" method="POST">

    <div class="form-group row">
        <label for="inputid" class="col-sm-2 col-form-label">ID</label>
        <div class="col-sm-10">
            <input name="id" type="int" class="form-control" id="inputid" placeholder="Introduzca un ID">
        </div>
    </div>

    <div class="form-group row">
        <label for="inputemail" class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-10">
            <input name="email" type="text" class="form-control" id="inputemail" placeholder="sunombre@example.com">
        </div>
    </div>

    <div class="form-group row">
        <label for="inputpassword" class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-10">
            <input name="password" type="password" class="form-control" id="inputpassword" placeholder="contraseña">
        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Register</button>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/david/Escritorio/2022-1/Topicos Software/taller1/resources/views/home/activity2.blade.php ENDPATH**/ ?>