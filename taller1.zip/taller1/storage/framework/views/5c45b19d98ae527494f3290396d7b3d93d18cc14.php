<?php $__env->startSection('title', $viewData["title"]); ?>

<?php $__env->startSection('subtitle', $viewData["subtitle"]); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('deleted')): ?>
<div class="alert alert-danger">
    <p><?php echo e(session('deleted')); ?></p>
</div>
<?php endif; ?>

<div class="row">

    <?php $__currentLoopData = $viewData["userStores"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userStore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-md-4 col-lg-3 mb-2">

        <div class="card">

            <img src="https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png?20200919003010">

            <div class="card-body text-center">

                <p class="<?php if($loop->index < 2): ?> <?php echo e('fw-bold'); ?> <?php endif; ?>"><?php echo e($userStore["id"]); ?></p>
                <a href="<?php echo e(route('users.show', ['id'=> $userStore['id']])); ?>" class="btn bg-primary text-white"><?php echo e($userStore["email"]); ?></a>

            </div>

        </div>

    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/david/Escritorio/2022-1/Topicos Software/taller1/resources/views/users/index.blade.php ENDPATH**/ ?>