<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserStore;

class UserController extends Controller

{
    public function create()

    {

        return view('users.create');
    }

    public function save(Request $request)
    {
        $request->validate([
            "id" => "required",
            "email" => "required",
            "password" => "required"
        ]);
        UserStore::create($request->only([
            "id", "email", "password"
        ]));
        return redirect()->back()->with('success', 'Usuario agregado');
    }

    public function index()

    {
        $viewData = [];

        $viewData["title"] = "Users";

        $viewData["subtitle"] = "List of users";

        $viewData["userStores"] = UserStore::all()->reverse();

        return view('users.index')->with("viewData", $viewData);
    }

    public function show($id)

    {

        $viewData = [];

        $userStore = UserStore::findOrFail($id);

        $viewData["userStore"] = $userStore;

        return view('users.show')->with("viewData", $viewData);
    }

    public function delete($id)

    {
        $userStore = UserStore::findOrFail($id);
        $userStore->delete();
        return redirect()->route('users.index')->with('deleted', 'Usuario eliminado');
    }
}
