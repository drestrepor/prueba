<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserStore extends Model
{
    use HasFactory;

    protected $table = 'users_store';

    protected $fillable = ['id', 'email', 'password'];

    public function getId()

    {

        return $this->attributes['id'];
    }

    public function setId($id)

    {

        $this->attributes['id'] = $id;
    }

    public function getName()

    {

        return $this->attributes['name'];
    }

    public function setName($name)

    {

        $this->attributes['name'] = $name;
    }

    public function setPassword($password)

    {

        $this->attributes['password'] = $password;
    }
}
